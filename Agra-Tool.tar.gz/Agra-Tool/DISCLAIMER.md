# Disclaimer

Agra Tool is provided for educational and authorized use only.

Use it only on systems, accounts, networks, and data that you own or have explicit permission to test. You are responsible for complying with all applicable laws and platform rules.

The authors and distributors are not responsible for misuse, damage, service disruption, data loss, or legal consequences caused by this software.
