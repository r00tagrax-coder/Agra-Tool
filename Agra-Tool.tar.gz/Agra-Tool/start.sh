#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")"

PYEXE="${PYTHON:-}"
if [ -z "$PYEXE" ]; then
    if command -v python3 >/dev/null 2>&1; then
        PYEXE="python3"
    elif command -v python >/dev/null 2>&1; then
        PYEXE="python"
    else
        echo "ERROR: Python 3.8+ is required."
        exit 1
    fi
fi

"$PYEXE" -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" || {
    echo "ERROR: Python 3.8+ is required."
    "$PYEXE" --version || true
    exit 1
}

exec "$PYEXE" -u "Void/main.py"
