# Agra Tool

Agra Tool is a modular terminal toolkit built with Python and Rich.

## Features

- Default blue theme
- ASCII-friendly terminal UI
- Linux launcher: `./start.sh`
- Linux setup: `./setup.sh`
- Windows launcher: `start.bat`
- Windows setup: `setup.bat`
- Plugin folder: `Void/tools/custom/`

## Linux

```sh
./setup.sh
./start.sh
```

## Windows

```bat
setup.bat
start.bat
```

## Controls

- `W` / `S`: move up and down
- `A` / `D`: move left and right
- Arrow keys: also supported
- `Enter`: select
- `F`: search

## Settings

Default settings live in `Void/config/settings.example.json`.

The default theme is:

```json
{
  "theme": "blue"
}
```

## License

GNU AGPL v3.0. See `Void/LICENSE` and `DISCLAIMER.md`.
