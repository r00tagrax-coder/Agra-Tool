"""Main dashboard -- Rich layout, live clock, sidebar scroll."""
import shutil
import time

from rich.console import Group
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from . import constants as C
from . import remote as R
from .config import get_settings, nuker_status
from .pages import build_pages_data
from .plugins import discover_plugins
from .search import run_search_ui
from .ui import make_card_cell, make_title_text, monitor_block
from .void_common import (
    cls,
    flush_console_keys,
    is_arrow,
    is_premium,
    poll_console_key,
    restore_console_key_mode,
    safe_action,
    sort_free_first,
)

class MasterRouter:
    MAX_ROWS = 4
    MAX_CAT_VISIBLE = 9

    def __init__(self):
        self.settings = get_settings()
        self.phone_mode = self.settings.get("runtime_mode") == "termux"
        self.max_rows = 6 if self.phone_mode else self.MAX_ROWS
        self.max_cat_visible = 6 if self.phone_mode else self.MAX_CAT_VISIBLE
        self.grid_cols = 1 if self.phone_mode else 2
        plugins = discover_plugins()
        cats = [
            ("home", "HOME"), ("osint", "OSINT"), ("attack", "ATTACK"),
            ("nuker", "NUKER"), ("discord", "DISCORD"), ("webhook", "WEBHOOK"),
            ("social", "SOCIAL"),
            ("roblox", "ROBLOX"), ("ip-web", "IP / WEB"), ("generator", "GEN"),
            ("crypto-utils", "UTILS"), ("darkweb", "DARKWEB"), ("about", "ABOUT"),
        ]
        if plugins:
            cats.insert(-1, ("plugins", "PLUGINS"))
        self.categories = cats
        self.cat_idx = 0
        self.cat_scroll = 0
        self.grid_idx = 0
        self.scroll_row = 0
        self.focus = "sidebar"
        self.running = True
        self._nuker = (False, False)
        self._nuker_at = 0.0
        self._next_remote = time.time() + 300
        self.pages_data = build_pages_data(plugins)
        skip = {"nuker", "home", "about", "darkweb", "generator", "crypto-utils", "plugins"}
        for key, items in self.pages_data.items():
            items = [
                item for item in items
                if not is_premium(item[1])
                and str(item[1]).strip().lower() != "premium shop"
            ]
            if key not in skip:
                self.pages_data[key] = sort_free_first(items)
            else:
                self.pages_data[key] = items

    def _cat_key(self):
        return self.categories[self.cat_idx][0]

    def _tools(self):
        return self.pages_data.get(self._cat_key(), [])

    def _nuker_state(self):
        now = time.time()
        if now - self._nuker_at > 5.0:
            self._nuker = nuker_status()
            self._nuker_at = now
        return self._nuker

    def _sync_cat_scroll(self):
        n = len(self.categories)
        max_scroll = max(0, n - self.max_cat_visible)
        if self.cat_idx < self.cat_scroll:
            self.cat_scroll = self.cat_idx
        elif self.cat_idx >= self.cat_scroll + self.max_cat_visible:
            self.cat_scroll = self.cat_idx - self.max_cat_visible + 1
        self.cat_scroll = max(0, min(self.cat_scroll, max_scroll))

    def _sync_scroll(self):
        tools = self._tools()
        n = len(tools)
        if not n:
            self.scroll_row = 0
            return
        total_rows = (n + self.grid_cols - 1) // self.grid_cols
        active_row = self.grid_idx // self.grid_cols
        max_scroll = max(0, total_rows - self.max_rows)
        if active_row < self.scroll_row:
            self.scroll_row = active_row
        elif active_row >= self.scroll_row + self.MAX_ROWS:
            self.scroll_row = active_row - self.MAX_ROWS + 1
        self.scroll_row = max(0, min(self.scroll_row, max_scroll))

    def build_ui(self):
        s = self.settings
        tools = self._tools()
        phase = (time.time() * 0.15) % 1.0 if C.is_rainbow() else 0.0
        pal = C.palette(phase)
        n = len(tools)
        if n:
            self.grid_idx = max(0, min(n - 1, self.grid_idx))
        else:
            self.grid_idx = 0
        self._sync_cat_scroll()
        self._sync_scroll()

        layout = Layout()
        layout.split_column(Layout(name="header", size=4), Layout(name="main"))
        layout["main"].split_row(Layout(name="sidebar", size=24 if self.phone_mode else 30), Layout(name="body"))

        head = Table.grid(expand=True)
        head.add_column(ratio=1, justify="left")
        head.add_column(ratio=2, justify="center")
        head.add_column(ratio=1, justify="right")
        mode_label = "TERMUX" if self.phone_mode else "KONSOLE"
        head.add_row(
            Text.from_markup(f"[{pal['neon']} bold]ONLINE[/]"),
            make_title_text(C.APP_NAME, phase),
            Text.from_markup(f"[bold {pal['neon']}]{mode_label}[/]"),
        )
        badge = R.status_badge()
        sub = f"[ {time.strftime('%H:%M:%S')} ]"
        if badge:
            sub += f"  [{C.C_GOLD} bold]! {badge}[/]"
        layout["header"].update(Panel(
            head, border_style=pal["blood"], box=box.ASCII,
            subtitle=sub,
        ))

        sidebar = Table.grid(expand=True)
        n_cat = len(self.categories)
        cat_up = f"[{pal['neon']}]^[/]" if self.cat_scroll > 0 else " "
        cat_dn = f"[{pal['neon']}]v[/]" if self.cat_scroll + self.MAX_CAT_VISIBLE < n_cat else " "
        sidebar.add_row(Text.from_markup(f"[{C.C_DIM}]{cat_up} {cat_dn}[/]"))

        end_cat = min(n_cat, self.cat_scroll + self.max_cat_visible)
        for i in range(self.cat_scroll, end_cat):
            _, label = self.categories[i]
            act = i == self.cat_idx
            foc = act and self.focus == "sidebar"
            width = 16 if self.phone_mode else 22
            if foc:
                sidebar.add_row(Text.from_markup(f"[black on {pal['neon']} bold] >> {label:<{width}} [/]"))
            elif act:
                sidebar.add_row(Text.from_markup(f"[{pal['neon']} bold] > {label:<{width}} [/]"))
            else:
                sidebar.add_row(Text.from_markup(f"[{C.C_DIM}] | {label:<{width}} [/]"))

        cat_label = self.categories[self.cat_idx][1]
        layout["sidebar"].update(Panel(
            Group(sidebar, monitor_block(cat_label, n, tools, s.username, self._nuker_state(), R.status_badge(), phase)),
            title="[bold white]CATEGORIES",
            border_style=pal["mid"],
            box=box.ASCII,
            padding=(1, 2),
        ))

        start = self.scroll_row * self.grid_cols
        end = min(n, start + self.max_rows * self.grid_cols)
        visible = tools[start:end]
        grid = Table.grid(expand=True, padding=(1, 1))
        grid.add_column(ratio=1)
        if self.grid_cols == 2:
            grid.add_column(ratio=1)
        for i in range(0, len(visible), self.grid_cols):
            row_items = visible[i:i + self.grid_cols]
            cells = []
            for offset, item in enumerate(row_items):
                abs_idx = start + i + offset
                cells.append(make_card_cell(item[0], item[1], self.focus == "grid" and self.grid_idx == abs_idx, phase))
            if self.grid_cols == 2 and len(cells) == 1:
                cells.append(Text(""))
            grid.add_row(*cells)

        total_rows = max(1, (n + self.grid_cols - 1) // self.grid_cols)
        up = f"[{pal['neon']}] ^ MORE UP [/]" if self.scroll_row > 0 else "                  "
        dn = f"[{pal['neon']}] v MORE DOWN [/]" if self.scroll_row + self.max_rows < total_rows else "                  "
        footer = Text.assemble(
            Text.from_markup(up), Text("   "), Text.from_markup(dn),
            Text("   "), Text.from_markup(f"[{C.C_DIM}]WASD / Arrows . Enter . F[/]"),
        )
        layout["body"].update(Panel(
            grid,
            title=f"[bold white]{cat_label}",
            subtitle=footer,
            border_style=pal["blood"],
            box=box.ASCII,
            padding=(1, 2),
        ))
        return layout

    def _on_arrow(self, k):
        tools = self._tools()
        n = len(tools)

        if k == b"H":
            if self.focus == "sidebar":
                self.cat_idx = (self.cat_idx - 1) % len(self.categories)
                self.grid_idx = 0
                self.scroll_row = 0
                self._sync_cat_scroll()
            else:
                self.grid_idx = max(0, self.grid_idx - self.grid_cols)
                self._sync_scroll()
        elif k == b"P":
            if self.focus == "sidebar":
                self.cat_idx = (self.cat_idx + 1) % len(self.categories)
                self.grid_idx = 0
                self.scroll_row = 0
                self._sync_cat_scroll()
            else:
                if n:
                    if self.grid_idx + self.grid_cols < n:
                        self.grid_idx += self.grid_cols
                    elif self.grid_idx + 1 < n:
                        self.grid_idx += 1
                self._sync_scroll()
        elif k == b"K":
            if self.focus == "grid":
                if self.grid_cols == 1 or self.grid_idx % 2 == 0:
                    self.focus = "sidebar"
                else:
                    self.grid_idx -= 1
        elif k == b"M":
            if self.focus == "sidebar":
                self.focus = "grid"
                self.grid_idx = 0
            elif self.grid_cols == 2 and self.grid_idx % 2 == 0 and n:
                self.grid_idx = min(n - 1, self.grid_idx + 1)

    def _on_key(self, k):
        wasd = {b"w": b"H", b"W": b"H", b"s": b"P", b"S": b"P", b"a": b"K", b"A": b"K", b"d": b"M", b"D": b"M"}
        if k in wasd:
            k = wasd[k]

        if is_arrow(k):
            self._on_arrow(k)
            return "redraw"

        if k == b"\r":
            flush_console_keys()
            if self.focus == "grid":
                tools = self._tools()
                if tools and self.grid_idx < len(tools):
                    return ("run", tools[self.grid_idx][2], tools[self.grid_idx][1])
            else:
                self.focus = "grid"
                self.grid_idx = 0
            return "redraw"

        if k in (b"f", b"F"):
            flush_console_keys()
            return "search"

        if k == b"\x03":
            return "exit"

        return None

    def _run_tool(self, live, action, label="Module"):
        live.stop()
        restore_console_key_mode()
        cls()
        safe_action(action, label)
        restore_console_key_mode()
        cls()
        live.start()

    def start(self):
        cols, rows = shutil.get_terminal_size((100, 30))
        min_cols, min_rows = (58, 20) if self.phone_mode else (90, 28)
        if cols < min_cols or rows < min_rows:
            cls()
            print(f"\n  [!] Terminal trop petit ({cols}x{rows}). Min ~{min_cols}x{min_rows}.\n")
            restore_console_key_mode()
            input("  Enter...")
        cls()
        with Live(self.build_ui(), auto_refresh=False, screen=True, transient=False) as live:
            next_clock = time.time()
            while self.running:
                now = time.time()
                if now >= next_clock:
                    live.update(self.build_ui(), refresh=True)
                    next_clock = now + 1.0
                    if now >= self._next_remote:
                        R.sync()
                        self._next_remote = now + 300

                k = poll_console_key()
                if k is None:
                    time.sleep(0.03)
                    continue
                res = self._on_key(k)
                if res == "exit":
                    break
                if isinstance(res, tuple):
                    self._run_tool(live, res[1], res[2])
                elif res == "search":
                    run_search_ui(self, live)
                if res:
                    live.update(self.build_ui(), refresh=True)
                    next_clock = time.time() + 1.0
