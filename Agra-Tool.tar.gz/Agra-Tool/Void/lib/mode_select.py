"""Runtime mode selector shown after the boot animation."""

from rich.align import Align
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from . import constants as C
from .config import get_settings
from .void_common import cls, console, read_console_key, restore_console_key_mode


MODES = [
    ("termux", "TERMUX", "Telefon mod", "Dar ekran, tek sutun dashboard"),
    ("konsole", "KONSOLE", "PC mod", "Genis ekran, klasik dashboard"),
]


def _draw(selected):
    cls()
    s = get_settings()
    pal = C.palette()
    current = s.get("runtime_mode", "konsole")

    header = Panel(
        Align.center(Text.from_markup(
            f"[bold {pal['neon']}]{C.APP_NAME}[/]\n"
            f"[{C.C_DIM}]Calisma modunu sec[/]"
        )),
        border_style=pal["blood"],
        box=box.ASCII,
        padding=(1, 3),
    )

    grid = Table.grid(expand=True, padding=(1, 2))
    grid.add_column(ratio=1)
    grid.add_column(ratio=1)

    cards = []
    for idx, (key, title, subtitle, desc) in enumerate(MODES):
        active = idx == selected
        saved = key == current
        marker = ">>" if active else "  "
        saved_text = f"\n[{C.C_GOLD}]Kayitli mod[/]" if saved else ""
        cards.append(Panel(
            Align.center(Text.from_markup(
                f"[bold {pal['neon'] if active else C.C_WHITE}]{marker} {title}[/]\n"
                f"[{C.C_SILVER}]{subtitle}[/]\n\n"
                f"[{C.C_DIM}]{desc}[/]"
                f"{saved_text}"
            )),
            title=f"[bold {C.C_GOLD}]0{idx + 1}[/]",
            border_style=pal["neon"] if active else C.C_DIM,
            box=box.ASCII,
            padding=(1, 2),
        ))

    grid.add_row(cards[0], cards[1])
    footer = Panel(
        Align.center(Text.from_markup(f"[{C.C_DIM}]A/D veya oklar . Enter ile devam[/]")),
        border_style=C.C_DIM,
        box=box.ASCII,
    )
    console.print(header)
    console.print(grid)
    console.print(footer)


def select_runtime_mode():
    """Ask for Termux or Konsole mode and persist the choice."""
    s = get_settings()
    current = s.get("runtime_mode", "konsole")
    selected = 0 if current == "termux" else 1

    while True:
        _draw(selected)
        key = read_console_key()

        if key in (b"a", b"A", b"w", b"W", b"K", b"H"):
            selected = (selected - 1) % len(MODES)
        elif key in (b"d", b"D", b"s", b"S", b"M", b"P"):
            selected = (selected + 1) % len(MODES)
        elif key in (b"1", b"2"):
            selected = int(key) - 1
        elif key == b"\r":
            mode = MODES[selected][0]
            s.set("runtime_mode", mode)
            s.save()
            restore_console_key_mode()
            cls()
            return mode
