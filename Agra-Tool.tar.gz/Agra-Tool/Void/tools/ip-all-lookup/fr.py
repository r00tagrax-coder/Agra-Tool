import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, socket, ssl, json, threading
import requests
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich import box

console = Console()

ASCII = r"""
  ???   ??? ??????? ??????????       ?????????? 
  ???   ???????????????????????      ???????????
  ???   ??????   ?????????  ????????????????????
  ???? ???????   ?????????  ??????????????????? 
   ??????? ????????????????????      ??????     
    ?????   ??????? ??????????       ??????     
"""
SUBTITLE = "G E O I N T E L L I G E N C E   E T   O R A C L E   R E S E A U   A V A N C E"

def boot():
    if sys.platform.startswith("win"):
        os.system("title VOID // IP ORACLE")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write(" ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        v = max(40, min(255, int(100 + 155 * math.sin(t * 10 - c * 0.12))))
                        sys.stdout.write(f"\033[38;2;{v};0;0m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  \033[38;2;80;0;0m{SUBTITLE}\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def current_time_hour():
    return time.strftime("%H:%M:%S")

def _req(url):
    try:
        r = requests.get(url, timeout=7, headers={"User-Agent": "Mozilla/5.0"})
        return r.json()
    except: return {}

def ssl_probe(host):
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, 443), timeout=4) as raw:
            with ctx.wrap_socket(raw, server_hostname=host) as tls:
                cert = tls.getpeercert(binary_form=False)
                if not cert: return {"ver": tls.version()}
                return {
                    "subject": dict(x[0] for x in cert.get("subject", [])).get("commonName", "--"),
                    "issuer": dict(x[0] for x in cert.get("issuer", [])).get("organizationName", "--"),
                    "expires": cert.get("notAfter", "--"),
                    "ver": tls.version()
                }
    except: return {}

def port_sample(ip):
    ports = {21:"FTP", 22:"SSH", 80:"HTTP", 443:"HTTPS", 3306:"MySQL", 3389:"RDP", 8080:"HTTP-Alt"}
    found = []
    def probe(p):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.8)
                if s.connect_ex((ip, p)) == 0:
                    found.append((p, ports[p]))
        except: pass
    threads = [threading.Thread(target=probe, args=(p,)) for p in ports]
    for t in threads: t.start()
    for t in threads: t.join()
    return sorted(found)

if __name__ == "__main__":
    try:
        boot()
        console.print(Align.center(Panel(
            Text.from_markup("[bold blue]Agra Tool[/]  [dim]//[/]  [white]IP ORACLE[/]  [dim]//[/]  [blue]DEEP TRACE[/]"),
            border_style="blue", padding=(0, 6)
        )))
        console.print()

        console.print(" [bold blue]+-[[/][bold white] IP ou Domaine Cible [/][bold blue]][/]")
        target = console.input(" [bold blue]+-?[/] [bold white]").strip()
        if not target: sys.exit(0)

        # Resolve
        if not target.replace(".","").isdigit():
            try:
                resolved = socket.gethostbyname(target)
                console.print(f" [dim]Resolu [blue]{target}[/] > [white]{resolved}[/]")
                ip = resolved
            except:
                console.print(" [bold blue][!] Echec de resolution DNS.")
                ip = target
        else: ip = target

        console.print(f"\n [dim]Lancement de l'Intelligence multi-sources sur [blue]{ip}[/]...\n")

        results = {}
        def fetch_geo():
            results["api"] = _req(f"http://ip-api.com/json/{ip}?fields=66846719")
        def fetch_ssl():
            results["ssl"] = ssl_probe(ip)
        def fetch_ports():
            results["ports"] = port_sample(ip)
        
        threads = [threading.Thread(target=fetch_geo), threading.Thread(target=fetch_ssl), threading.Thread(target=fetch_ports)]
        for t in threads: t.start()
        for t in threads: t.join()

        geo = results.get("api", {})
        ssl_d = results.get("ssl", {})
        ports = results.get("ports", [])

        # Geo Table
        gtbl = Table(box=box.ASCII, border_style="blue", show_header=False)
        gtbl.add_column("K", style="dim red"); gtbl.add_column("V", style="white")
        gtbl.add_row("PAYS", geo.get("country", "--"))
        gtbl.add_row("VILLE", geo.get("city", "--"))
        gtbl.add_row("REGION", geo.get("regionName", "--"))
        gtbl.add_row("FAI", geo.get("isp", "--"))
        gtbl.add_row("ASN", geo.get("as", "--"))
        gtbl.add_row("PROXY/VPN", "[bold blue]DETECTE[/]" if geo.get("proxy") else "Non")
        gtbl.add_row("DATACENTER", "Oui" if geo.get("hosting") else "Non")
        
        console.print(Align.center(Panel(gtbl, title="[bold blue] GEOLOCALISATION [/]", border_style="blue")))

        if ssl_d:
            stbl = Table(box=box.ASCII, border_style="blue", show_header=False)
            stbl.add_row("NOM COMMUN", ssl_d.get("subject", "--"))
            stbl.add_row("EMETTEUR", ssl_d.get("issuer", "--"))
            stbl.add_row("EXPIRE LE", ssl_d.get("expires", "--"))
            stbl.add_row("VERSION TLS", ssl_d.get("ver", "--"))
            console.print(Align.center(Panel(stbl, title="[bold blue] CERTIFICAT SSL [/]", border_style="blue")))

        if ports:
            ptbl = Table(box=box.ASCII, border_style="blue", show_header=True, header_style="bold red")
            ptbl.add_column("PORT", style="cyan"); ptbl.add_column("SERVICE")
            for p, s in ports: ptbl.add_row(str(p), s)
            console.print(Align.center(Panel(ptbl, title="[bold blue] SERVICES OUVERTS [/]", border_style="blue")))

        console.print()
        console.input(" [dim]Appuyez sur [bold blue]ENTREE[/] pour quitter...[/]")

    except (KeyboardInterrupt, EOFError):
        pass
