#!/usr/bin/env python3
"""Agra Tool - v2.1"""
import os
import sys

# Fix imports when launched via start.bat (cwd = Agra Tool root)
_VOID = os.path.dirname(os.path.abspath(__file__))
if _VOID not in sys.path:
    sys.path.insert(0, _VOID)

try:
    from lib.entry import run_void
except ModuleNotFoundError as exc:
    print(f"Missing Python dependency: {exc.name}")
    print("Run ./setup.sh from the project root, then start Agra Tool with ./start.sh")
    raise SystemExit(1) from exc

if __name__ == "__main__":
    run_void()
